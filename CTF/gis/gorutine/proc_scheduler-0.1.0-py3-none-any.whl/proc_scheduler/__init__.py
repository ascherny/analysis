"""
Proc Scheduler - A simple asyncio-based process scheduler

This package provides classes and decorators for managing asynchronous processes
with timeouts and state management.
"""

from .scheduler import Process, ProcessStatus, Scheduler, go

__version__ = "0.1.0"
__all__ = ["Process", "ProcessStatus", "Scheduler", "go"]
