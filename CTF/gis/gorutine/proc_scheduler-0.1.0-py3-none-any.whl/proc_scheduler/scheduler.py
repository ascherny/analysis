import asyncio
from asyncio import Event, Task
from collections import deque
from enum import Enum, auto
from functools import wraps
from typing import Callable, Coroutine


class ProcessStatus(Enum):
    READY = auto()
    RUNNING = auto()
    STOPED = auto()
    COMPLETED = auto()
    FAILED = auto()


class Process:
    def __init__(
        self,
        name: str,
        pid: int,
        task: Callable[[Event, dict], Coroutine] | None = None,
    ):
        self.name = name
        self.task = task
        self.status = ProcessStatus.READY
        self.pid = pid

    def run(self, e: Event, state: dict) -> Task:
        if self.task is None:
            raise ValueError("Task must be provided to run the process.")
        self.status = ProcessStatus.RUNNING
        return asyncio.create_task(self.task(e, state))


class Scheduler:
    def __init__(self):
        self.states = {}
        self.processes: deque[tuple[Process, Event]] = deque()

    def add_process(self, process: Process):
        self.processes.append((process, Event()))
        self.states[process.pid] = {}

    async def run(self):
        while self.processes:
            p, e = self.processes.popleft()

            if p.status in (ProcessStatus.READY, ProcessStatus.STOPED):
                try:
                    task = p.run(e, self.states[p.pid])
                    await asyncio.wait_for(task, timeout=1)
                except asyncio.TimeoutError:
                    e.set()
                    p.status = ProcessStatus.STOPED
                    e.clear()
                    self.processes.append((p, e))
                else:
                    if task.result()[1]:
                        p.status = ProcessStatus.COMPLETED
                        print(
                            f"Process {p.pid} completed:",
                            self.states[p.pid].get("result"),
                        )
                    else:
                        e.clear()
                        self.processes.append((p, e))


def go(f) -> Callable[[Event, dict], Coroutine]:
    @wraps(f)
    async def wrapper(e: Event, state: dict) -> tuple[int | None, bool]:
        task = asyncio.create_task(f(state))
        while True:
            if task.done():
                result = task.result()

                if result:
                    return result, True

            if e.is_set():
                task.cancel()
                break
            await asyncio.sleep(0)

        return None, False

    return wrapper
